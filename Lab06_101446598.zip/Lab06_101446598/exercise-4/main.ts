import { Customer } from "./customer";

let customer = new Customer("Mia", "T", 30);
customer.greet();  
customer.getAge(); 
