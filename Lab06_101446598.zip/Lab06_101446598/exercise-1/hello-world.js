var greet = function (firstName, lastName) {
    console.log("Hello, ".concat(firstName, " ").concat(lastName, "!"));
};
greet("John", "Doe");
