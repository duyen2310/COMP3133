let greet = (firstName: string, lastName: string): void => {
    console.log(`Hello, ${firstName} ${lastName}!`);
  };
  
  greet("John", "Doe");
  